#!/usr/bin/env python3
from __future__ import annotations
import pathlib
import re
import sys

ROOT = pathlib.Path.cwd()
TARGET = ROOT / "src" / "app" / "contract" / "page.tsx"

def die(msg: str, code: int = 1):
    print(msg, file=sys.stderr)
    sys.exit(code)

if not TARGET.exists():
    die(f"❌ Fichier introuvable: {TARGET}\nLance ce script depuis la racine du repo (là où il y a package.json).")

src = TARGET.read_text(encoding="utf-8")

if 'export const dynamic = "force-dynamic";' in src or "export const dynamic='force-dynamic';" in src:
    print("✅ Rien à faire: dynamic déjà présent.")
    sys.exit(0)

# Insert after last import (preferred), else at top
lines = src.splitlines(True)

# Find last import line index
last_import_idx = -1
for i, line in enumerate(lines):
    if re.match(r'^\s*import\s', line):
        last_import_idx = i

insert_line = 'export const dynamic = "force-dynamic";\n\n'

if last_import_idx >= 0:
    # insert after last import block (skip possible empty line after imports)
    j = last_import_idx + 1
    # keep one blank line after imports; we insert after imports and any single blank line
    while j < len(lines) and lines[j].strip() == "":
        # stop at first blank line after imports, we'll insert there (keeping existing blank line)
        j += 1
        break
    lines.insert(j, insert_line)
else:
    lines.insert(0, insert_line)

out = "".join(lines)
TARGET.write_text(out, encoding="utf-8")
print(f"✅ Patch appliqué: {TARGET}\n➡️ Prochain: npm run build (vérifie que /contract est en ƒ)")
