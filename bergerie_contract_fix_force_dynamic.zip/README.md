# Bergerie-site — Fix "rid manquant" (force dynamique)

## Pourquoi
La page /contract est actuellement buildée en **statique**. Dans ce cas, la vérification du paramètre `rid` peut être faite au build (sans query string), ce qui donne "Lien invalide : rid manquant" même si l'URL contient `?rid=...`.

Le correctif force la route **/contract** en rendu dynamique côté Next.js pour que `searchParams` soit bien pris en compte en prod.

## Application (terminal)
1) Place ce zip dans le dossier racine du repo (là où il y a `package.json`)
2) Puis :

```bash
unzip -o bergerie_contract_fix_force_dynamic.zip -d .tmp_force_dynamic
python3 .tmp_force_dynamic/scripts/patch_force_dynamic.py
rm -rf .tmp_force_dynamic
```

3) Vérifie :
```bash
npm run build
```
Dans le tableau des routes, `/contract` doit apparaître en **ƒ (Dynamic)** et plus en **O (Static)**.

4) Commit + push :
```bash
git add -A
git commit -m "fix: force /contract dynamic to keep rid query param"
git push
```

## Fichiers modifiés
- `src/app/contract/page.tsx` (ajoute `export const dynamic = "force-dynamic";` si absent)
